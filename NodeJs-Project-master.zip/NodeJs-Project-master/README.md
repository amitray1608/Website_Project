# Sports League Management Software

Built Completely on nodeJS and its frameworks.You can add players details and delete existing players, add photos of the game in the gallery and you can schedule tranining sessions.

## Technologies Used:-

* NodeJS
* EJS
* HTML
* CSS
* mongoDB
* Mongoose
* Semantic UI
## Framework:-
* Express

[See the live version on Heroku](https://sports90588.herokuapp.com)

